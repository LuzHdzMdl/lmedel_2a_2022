package program2a;

/*
 * Class Output
 *
 * Copyright (c) 2022-2023 UV. All Rights Reserved.
 */
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * @author luzme
 */
public class Output {

    public Output() {
    }

    /**
     * @param OutFile 
     * @param outText
     */

    public void writeData(String outFile, String outText) {
	
        BufferedWriter output = null;
        
        try 
    
            {
        
                File file = new File(outFile);
                output = new BufferedWriter(new FileWriter(file));
                output.write(outText);
                output.close();
            } 
    
        catch ( IOException e ) 
    
            {
                e.printStackTrace();
            }   
        }
}