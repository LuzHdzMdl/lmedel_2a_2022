package program2a;

/*
 * Class MethodCounter
 * @author luzme
 *
 * Copyright (c) 2022-2023 UV. All Rights Reserved.
 */
//import java.util.*;

/**
 * @author luzme
 */
public class MethodCounter {

    public int totalMethods=0;
    public int totalLines=0;
    public String arrData;
   

    public MethodCounter() {
    }

    /**
     * @param dataList 
     * @param n
     */
    public int countMethods(String[] dataList, int n) {

        
        for(int x = 0; x<n; x++){

            arrData = dataList[x].trim();           

            
                while((arrData.startsWith("private") || arrData.startsWith("public") || 
                        arrData.startsWith("protected")) &&  arrData.contains("(") && 
                        arrData.contains(")") && arrData.contains("{")){

                    totalMethods++;
                    totalLines++;

                    for (x=x+1; x<n; x++){
                        arrData = dataList[x].trim();           
                        
                
                        if((arrData.startsWith("private") || arrData.startsWith("public") || 
                        arrData.startsWith("protected")) &&  arrData.contains("(") && 
                        arrData.contains(")") && arrData.contains("{")){

                            System.out.println("\n    Metodo Número " + totalMethods + "\n    Total de lineas: " + totalLines);
                            totalLines=1;
                            totalMethods++;

                        } else if (!("".equals(arrData) || arrData.startsWith("//") || 
                            arrData.startsWith("}") || arrData.startsWith("/*") 
                            || arrData.startsWith("*/") || 
                            arrData.startsWith("*"))) {
                                totalLines++;
                        }
                    }     
                }        
        }
        System.out.println("\n    Metodo Número " + totalMethods + "\n    Total de lineas: " + totalLines);
        return totalMethods;
    }
}