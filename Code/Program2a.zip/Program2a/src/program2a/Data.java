package program2a;


/*
 * Class Data
 * @author luzme
 *
 * Copyright (c) 2022-2023 UV. All Rights Reserved.
 */

/**
 * @author luzme
 */
public class Data {

    public Data() {
    }

    /**
     * @param data
     */

    public String[] saveData(String data) {
        // throw new UnsupportedOperationException();
        String[] arrData = data.split(",");
        return arrData;
    }

}