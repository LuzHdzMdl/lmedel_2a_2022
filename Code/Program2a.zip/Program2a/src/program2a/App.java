package program2a;

/*
 * Class App
 * @author luzme
 *
 * Copyright (c) 2022-2023 UV. All Rights Reserved.
 */

/**
 * @author luzme
 */
public class App {

    public App() {
        
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        Logic myLogic = new Logic();
        myLogic.logic2a();
    }

}